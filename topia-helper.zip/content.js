/* TOPIA Helper: the Class Gradesheet's TOPIA tools as buttons on TOPIA pages (no bookmarks needed).
   Built from the gradesheet's own code; nothing is saved on TOPIA until the teacher presses Save. */
(function () {
  if (window.__gsHelper) return; window.__gsHelper = 1;
function topiaFillBookmarklet() {
  const sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  const until = async function (f, ms) { for (let t = 0; t < (ms || 8000); t += 150) { const v = f(); if (v) return v; await sleep(150); } return null; };
  const vis = function (el) { return !!(el && el.offsetParent); };
  const norm = function (s) { return String(s || '').toLowerCase().replace(/[^a-z0-9가-힣]/g, ''); };
  const setSelect = function (s, v) { Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value').set.call(s, v); s.dispatchEvent(new Event('input', { bubbles: true })); s.dispatchEvent(new Event('change', { bubbles: true })); };
  const sels = function () { return Array.from(document.querySelectorAll('select')).filter(vis); };
  const sessionSel = function () { return sels().find(function (s) { return Array.from(s.options).some(function (o) { return /회차/.test(o.text); }); }); };
  const classSel = function () { return sels().find(function (s) { return Array.from(s.options).some(function (o) { return /_\d+\s*\(/.test(o.text); }); }); };
  const clsKey = function (t) { return norm(String(t).split('(')[0]); };
  const grp = function (l) { return /particip/i.test(l) ? 'participation' : /writ|essay|summary/i.test(l) ? 'writing' : /word|vocab|idiom/i.test(l) ? 'vocab' : /present|debate|speech/i.test(l) ? 'presentation' : /monthly/i.test(l) ? 'monthly' : ''; };
  const run = async function (txt) {
    if (!txt || txt.indexOf('#GS-TOPIA') !== 0) { alert('Copy the scores in the gradesheet first (Copy Day N for TOPIA).'); return; }
    let data; try { data = JSON.parse(txt.slice(10)); } catch (e) { alert('Those copied scores could not be read. Copy them again.'); return; }
    let ss = sessionSel();
    if (!ss) {
      const cs = classSel();
      if (cs && clsKey(cs.options[cs.selectedIndex].text) !== clsKey(data.cls)) {
        const o = Array.from(cs.options).find(function (x) { return clsKey(x.text) === clsKey(data.cls); });
        if (!o) { alert('TOPIA has no class called ' + data.cls + '. Pick the class here, then try again.'); return; }
        setSelect(cs, o.value); await sleep(1500);
      }
      const reg = await until(function () { return Array.from(document.querySelectorAll('button')).find(function (b) { return vis(b) && /^\s*(register|등록)\s*$/i.test(b.innerText); }); }, 5000);
      if (!reg) { alert('Open TOPIA → Weekly Report first, then click the bookmark.'); return; }
      reg.click(); ss = await until(sessionSel);
      if (!ss) { alert('The Register form did not open. Click Register, then try again.'); return; }
    }
    const want = Array.from(ss.options).find(function (o) { return parseInt(o.text, 10) === data.day; });
    if (!want) { alert('TOPIA has no ' + data.day + '회차 for this class yet.'); return; }
    if (ss.value !== want.value) { setSelect(ss, want.value); await sleep(900); }
    const inputs = (await until(function () { const a = Array.from(document.querySelectorAll('input[name^="infoList."]')).filter(vis); return a.length ? a : null; })) || [];
    if (!inputs.length) { alert('No score boxes found on the Register form.'); return; }
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    let who = '', filled = 0; const seen = {}, missing = [];
    inputs.forEach(function (inp) {
      const tr = inp.closest('tr'), cells = tr ? Array.from(tr.cells) : [], n = cells.length;
      if (n >= 5) who = cells[n - 4].innerText;
      else for (let r = tr.previousElementSibling; r; r = r.previousElementSibling) { const nc = r.querySelector('td.col_name'); if (nc) { who = nc.innerText; break; } if (r.querySelector('input')) break; }
      const label = n >= 3 ? cells[n - 3].innerText : '', perfect = parseFloat(n >= 2 ? cells[n - 2].innerText : '') || 100;
      const parts = who.split(/[\n()]+/).map(norm).filter(Boolean);
      const row = data.rows.find(function (r) { return (r.kor && parts.indexOf(norm(r.kor)) >= 0) || (r.eng && parts.indexOf(norm(r.eng)) >= 0); });
      if (!row) { if (who && !seen[who]) { seen[who] = 1; missing.push(who.replace(/\s+/g, ' ').trim()); } return; }
      seen[who] = 1;
      const p = row.g[grp(label)]; if (p == null) return;
      setter.call(inp, String(Math.round(p * perfect / 100))); inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true }));
      inp.style.background = '#fff4b8'; filled++;
    });
    let box = document.getElementById('gsTopiaNote');
    if (!box) { box = document.createElement('div'); box.id = 'gsTopiaNote'; box.style.cssText = 'position:fixed;left:50%;top:16px;transform:translateX(-50%);z-index:99999;background:#fff4b8;color:#222;border:2px solid #c9a400;border-radius:10px;padding:12px 16px;font:15px/1.4 sans-serif;max-width:560px;box-shadow:0 6px 20px rgba(0,0,0,.25);cursor:pointer'; box.title = 'Click to close'; box.onclick = function () { box.remove(); }; document.body.appendChild(box); }
    box.textContent = '✓ Filled ' + filled + ' boxes: ' + data.cls + ', ' + data.day + '회차 (yellow).' + (missing.length ? ' Not in the gradesheet: ' + missing.join(', ') + '.' : '') + ' Check them, then press Save.';
    setTimeout(function () { if (box.isConnected) box.remove(); }, 15000);
  };
  const ask = function () { run(prompt('Paste the scores copied from the gradesheet:') || ''); };
  if (navigator.clipboard && navigator.clipboard.readText) navigator.clipboard.readText().then(run, ask); else ask();
}
function topiaHomeworkBookmarklet() {
  var GS = 'https://disconnekted.github.io/Class-tools/gradesheet.html';
  var API = 'https://front-api.topiaenglishzone.co.kr/v1/t/';
  var iPad = /iPad|iPhone/.test(navigator.userAgent) || (navigator.maxTouchPoints > 1 && /Mac/.test(navigator.platform));
  var win = iPad ? null : window.open('', 'gsOnline');
  if (win) { try { win.document.write('<p style="font:16px sans-serif;padding:20px">Reading online homework from TOPIA…</p>'); } catch (e) {} }
  function note(html) {
    var box = document.getElementById('gsTopiaNote');
    if (!box) { box = document.createElement('div'); box.id = 'gsTopiaNote'; box.style.cssText = 'position:fixed;left:50%;top:16px;transform:translateX(-50%);z-index:99999;background:#fff4b8;color:#222;border:2px solid #c9a400;border-radius:10px;padding:12px 16px;font:15px/1.4 sans-serif;max-width:560px;box-shadow:0 6px 20px rgba(0,0,0,.25)'; document.body.appendChild(box); }
    box.innerHTML = html + ' <a href="#" data-x style="margin-left:8px">close</a>';
    box.querySelector('[data-x]').onclick = function (e) { e.preventDefault(); box.remove(); };
    return box;
  }
  var tk = document.cookie.match(/__TP_ACCESS_TOKEN=([^;]+)/);
  if (!tk || !/topiaenglishzone/.test(location.hostname)) { if (win) win.close(); note('Log in to TOPIA (www.topiaenglishzone.co.kr) first, then try again.'); return; }
  var AH = { headers: { Authorization: 'Bearer ' + decodeURIComponent(tk[1]) } };
  // TOPIA's server is slow, so at most 6 requests run at once and a failed one is tried again.
  var busy = 0, waiting = [];
  var slot = function () { return new Promise(function (r) { if (busy < 6) { busy++; r(); } else waiting.push(r); }); };
  var free = function () { var n = waiting.shift(); if (n) n(); else busy--; };
  var get = async function (p) {
    for (var t = 0; t < 3; t++) {
      await slot();
      try { var r = await fetch(API + p, AH); if (r.ok) { var j = await r.json(); free(); return j; } } catch (e) {}
      free(); await new Promise(function (r) { setTimeout(r, 1500 * (t + 1)); });
    }
    return null;
  };
  // John's rule: Word Study and Matching Game done, plus tests 1, 2 and 3 each 80% or higher (rounded down), or all 5 tests done.
  function judge(st) {
    var t = {}; (st.pretestList || []).forEach(function (p) { t[p.studyTypeNum] = p; });
    var ws = !!st.isWordStudy, mg = !!st.isMatchStudy, done = Object.keys(t).length;
    var ok8 = function (p) { return p.correctCount >= Math.floor(p.wordCount * 0.8 + 1e-9); };
    var f3 = [1, 2, 3].every(function (n) { return t[n] && ok8(t[n]); }), all5 = [1, 2, 3, 4, 5].every(function (n) { return t[n]; });
    if (ws && mg && (f3 || all5)) return '';
    if (!ws && !mg && !done) return 'not started';
    var r = []; if (!ws) r.push('no Word Study'); if (!mg) r.push('no Matching Game');
    if (!(f3 || all5)) { var low = [1, 2, 3].filter(function (n) { return t[n] && !ok8(t[n]); }).map(function (n) { return 'T' + n + ' ' + Math.round(100 * t[n].correctCount / t[n].wordCount) + '%'; }); r.push(done ? done + ' of 5 tests' + (low.length ? ' (' + low.join(', ') + ')' : '') : 'no tests'); }
    return r.join(', ');
  }
  async function squeeze(obj) {
    var raw = new TextEncoder().encode(JSON.stringify(obj)), u8 = raw, tag = 'j';
    if (typeof CompressionStream === 'function') { u8 = new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(new CompressionStream('deflate-raw'))).arrayBuffer()); tag = 'z'; }
    var s = ''; for (var i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    return tag + btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  async function run() {
    note('Reading online homework from TOPIA…');
    var info = await get('class/info'), cls = info && info.data && info.data.list;
    if (!cls) { if (win) win.close(); note('Could not load your classes. Refresh TOPIA (log in again if asked) and try once more.'); return; }
    var out = [], nUnits = 0;
    await Promise.all(cls.map(async function (c) {
      var subs = (c.subjectList || []).map(function (s) { return String(s.sourceSubjectId); });
      var units = {}, shadow = {};
      await Promise.all([(async function () {
      var list = [];
      for (var pg = 1; pg < 10; pg++) { var j = await get('online-contents/onlineword?classId=' + c.classId + '&limit=100&page=' + pg), d = j && j.data; if (!d) break; list = list.concat(d.list || []); if (!d.hasNextPage) break; }
      list = list.filter(function (u) { return subs.indexOf(String(u.sourceSubjectObj && u.sourceSubjectObj.id)) >= 0 && u.countObj && u.countObj.participantCount > 0; });
      await Promise.all(list.map(async function (u) {
        var j = await get('online-contents/onlineword/' + c.classId + '/' + u.sourceSubjectObj.id + '/' + u.unitNum), L = j && j.data && j.data.list; if (!L) return;
        var p = [], f = [];
        L.forEach(function (st) { var s = st.studentObj || {}, nm = [String(s.nameE || '').trim(), String(s.nameK || '').trim()], why = judge(st); if (why) f.push(nm.concat(why)); else p.push(nm); });
        units[u.unitNum] = { name: u.unitName, p: p, f: f }; nUnits++; note('Reading online homework from TOPIA… ' + nUnits + ' so far');
      }));
      })(), (async function () {
      // Shadowing lives in the Homework (과제평가) grid: score 2 = done (O), 0 or 1 = not done.
      var today = new Date().toISOString().slice(0, 10);
      await Promise.all(subs.map(async function (sid) {
        var j = await get('class/homework/list?classId=' + c.classId + '&sourceSubjectId=' + sid), L = j && j.data && j.data.list;
        if (!L || !Array.isArray(L.studentInfolist)) return;
        L.studentInfolist.forEach(function (st) {
          var nm = [String(st.nameE || '').trim(), String(st.nameK || '').trim()];
          (st.homeworkList || []).forEach(function (h) {
            var o = h.onlineHomeworkInfo && h.onlineHomeworkInfo.shadowing, v = h.onlineHomeworkScoreInfo && h.onlineHomeworkScoreInfo.shadowing;
            if (!o || v == null || v === '') return;
            var d = String(h.classDate || '').slice(0, 10), k = o.unitNum + '|' + (o.unitDay || '');
            var u = shadow[k] || (shadow[k] = { u: String(o.unitNum), d: o.unitDay || '', date: d, name: o.name || '', p: [], f: [] });
            if (d && d < u.date) u.date = d;
            if (String(v) === '2') u.p.push(nm); else if (d && d < today) u.f.push(nm.concat('shadowing not done'));
          });
        });
      }));
      })()]);
      nUnits += Object.keys(shadow).length;
      out.push({ shadow: shadow, cls: c.className, subj: (c.subjectList || []).map(function (s) { return s.subjectName || s.name || ''; }).join('/'), units: units });
    }));
    var data = { app: 'gs-online', at: new Date().toISOString().slice(0, 10), classes: out };
    window.__gsOnlineData = data;
    var link = GS + '#online=' + await squeeze(data), text = '#GS-ONLINE ' + JSON.stringify(data);
    var copy = function (b) { var ok = function () { if (b) b.textContent = '✓ Copied'; }; (navigator.clipboard ? navigator.clipboard.writeText(text) : Promise.reject()).then(ok, function () { var ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); ok(); } catch (e) {} ta.remove(); }); };
    if (win) { win.location.href = link; note('✓ Read ' + nUnits + ' word units and shadowing lessons in ' + out.length + ' classes. The gradesheet opened in a new tab and ticked them.'); return; }
    var box = note('✓ Read ' + nUnits + ' word units and shadowing lessons in ' + out.length + ' classes. <button data-c style="font:inherit;padding:4px 10px">Copy</button> then tap <b>Paste online homework</b> in the gradesheet app, or <a href="' + link + '" target="_blank">open the gradesheet here</a>.');
    box.querySelector('[data-c]').onclick = function () { copy(this); };
    try { await navigator.clipboard.writeText(text); box.querySelector('[data-c]').textContent = '✓ Copied'; } catch (e) {}
  }
  run().catch(function (e) { if (win) win.close(); note('Something went wrong: ' + e.message); });
}
  var bar = document.createElement('div'); bar.id = 'gsHelperBar';
  bar.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:99998;display:flex;gap:6px;align-items:center;font:13px/1.2 sans-serif';
  function btn(label, title, fn) { var b = document.createElement('button'); b.type = 'button'; b.textContent = label; b.title = title; b.style.cssText = 'padding:7px 11px;border-radius:18px;border:1px solid #c9a400;background:#fff4b8;color:#222;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.18);font:inherit'; b.onclick = fn; return b; }
  var fillB = btn('✎ Fill from gradesheet', 'Fill the Register form with the scores copied from the gradesheet (you still press Save)', function () { topiaFillBookmarklet(); });
  var hwB = btn('⇩ Online homework → gradesheet', 'Read online word study and shadowing for all your classes and tick them in the gradesheet', function () { topiaHomeworkBookmarklet(); });
  var hide = btn('–', 'Hide these buttons until the page is reloaded', function () { bar.remove(); }); hide.style.padding = '7px 10px';
  function show() { fillB.style.display = /weekly-report/.test(location.pathname) ? '' : 'none'; }
  bar.append(fillB, hwB, hide); show();
  setInterval(show, 1000); // TOPIA changes pages without reloading
  (document.body ? Promise.resolve() : new Promise(function (r) { addEventListener('DOMContentLoaded', r); })).then(function () { document.body.appendChild(bar); });
})();
